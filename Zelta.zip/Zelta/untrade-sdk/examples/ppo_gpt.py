import os
import uuid
import gym
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv
from datetime import datetime
from untrade.client import Client

# Set a seed value for reproducibility
np.random.seed(1)

# === Load Data ===
def load_data(file_path):
    df = pd.read_csv(file_path)
    df['datetime'] = pd.to_datetime(df['datetime'])
    df.set_index('datetime', inplace=True)

    # Technical Indicators
    df['RSI'] = compute_rsi(df['close'], 14)
    df['EMA7'] = df['close'].ewm(span=7, adjust=False).mean()
    df['EMA14'] = df['close'].ewm(span=14, adjust=False).mean()
    df['EMA28'] = df['close'].ewm(span=28, adjust=False).mean()
    
    # Buy/Sell Signals
    df['Signal'] = 0
    df.loc[df['EMA7'] > df['EMA14'], 'Signal'] = 1  # Buy
    df.loc[df['EMA7'] < df['EMA14'], 'Signal'] = -1  # Sell

    df.dropna(inplace=True)
    return df

# === Compute RSI Indicator ===
def compute_rsi(series, period=14):
    delta = series.diff()
    gain = delta.where(delta > 0, 0).rolling(window=period).mean()
    loss = -delta.where(delta < 0, 0).rolling(window=period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

# === Custom Gym Trading Environment ===
class TradingEnv(gym.Env):
    def __init__(self, df, initial_balance=50000, transaction_cost=0.0015):
        super(TradingEnv, self).__init__()
        self.df = df
        self.index = 0
        self.balance = initial_balance
        self.position = 0
        self.net_worth = initial_balance
        self.transaction_cost = transaction_cost
        self.done = False

        # Define Action & Observation Space
        self.action_space = gym.spaces.Box(low=-1, high=1, shape=(1,), dtype=np.float32)  # Continuous actions
        self.observation_space = gym.spaces.Box(low=-np.inf, high=np.inf, shape=(5,))  # Features: Close, RSI, EMA7, EMA14, EMA28

    def reset(self):
        self.index = 0
        self.balance = 50000
        self.position = 0
        self.net_worth = 50000
        self.done = False
        return self._get_observation()

    def _get_observation(self):
        row = self.df.iloc[self.index]
        return np.array([row['close'], row['RSI'], row['EMA7'], row['EMA14'], row['EMA28']])

    def step(self, action):
        row = self.df.iloc[self.index]
        price = row['close']
        
        action = np.clip(action, -1, 1)  # Limit actions between -1 (Short) and 1 (Long)

        # Execute Buy/Sell action
        if action > 0:  # Buy
            investment = self.balance * action
            self.position += investment / price
            self.balance -= investment
        elif action < 0 and self.position > 0:  # Sell
            sale_amount = self.position * abs(action) * price
            self.balance += sale_amount
            self.position -= self.position * abs(action)

        # Calculate new Net Worth
        self.net_worth = self.balance + self.position * price
        reward = self._calculate_sharpe_ratio()

        # Move to next timestep
        self.index += 1
        if self.index >= len(self.df) - 1:
            self.done = True

        return self._get_observation(), reward, self.done, {}

    def _calculate_sharpe_ratio(self, risk_free_rate=0.01):
        returns = self.df['close'].pct_change().dropna()
        mean_return = returns.mean()
        std_return = returns.std()
        if std_return == 0:
            return 0  # Avoid division by zero
        return (mean_return - risk_free_rate) / std_return

# === Train PPO Model ===
def train_agent(file_path, episodes=50000):
    df = load_data(file_path)
    env = DummyVecEnv([lambda: TradingEnv(df)])  # Vectorized environment

    model = PPO("MlpPolicy", env, verbose=1, learning_rate=0.0003, gamma=0.99, ent_coef=0.01)
    model.learn(total_timesteps=episodes)

    model.save("ppo_trading_model")
    return model

# === Run Backtest ===
def perform_backtest(csv_file_path):
    client = Client()
    result = client.backtest(
        jupyter_id="team67_zelta_hpps",  # Replace with your Untrade ID
        file_path=csv_file_path,
        leverage=1
    )
    return result

# === Main Execution ===
def main():
    data_path = "C:\\Users\\super\\Desktop\\Zelta\\untrade-sdk\\examples\\ETHUSDT_1h.csv"
    
    # Train PPO Agent
    print("Training PPO Agent...")
    model = train_agent(data_path, episodes=50000)

    # Load Data and Environment for Testing
    test_df = load_data(data_path)
    test_env = TradingEnv(test_df)

    state = test_env.reset()
    done = False

    results = []
    while not done:
        action, _ = model.predict(state)
        state, _, done, _ = test_env.step(action)
        results.append(test_env.net_worth)

    # Save Results
    test_df['NetWorth'] = results
    csv_file_path = "btc_strategy_results.csv"
    test_df.to_csv(csv_file_path, index=False)

    # Perform Backtest
    print("Performing Backtest...")
    backtest_result = perform_backtest(csv_file_path)

    for value in backtest_result:
        print(value)

if __name__ == "__main__":
    main()
