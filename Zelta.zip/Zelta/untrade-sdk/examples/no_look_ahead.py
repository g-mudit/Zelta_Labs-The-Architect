import pandas as pd
import numpy as np
import talib
from hurst import compute_Hc
from scipy.stats import entropy as scipy_entropy
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from enum import Enum

class TradeType(Enum):
    LONG = "LONG"
    SHORT = "SHORT"
    CLOSE = "CLOSE"
    HOLD = "HOLD"

class Strategy:
    def run(self, data: pd.DataFrame) -> pd.DataFrame:
        class TradingStrategy:
            def __init__(self, data):
                self.data = data
                self.close = data['close'].values
                self.signals = pd.DataFrame(index=data.index)
                self.t_recalc = 84  # Adjusted for 4-hour data (2 weeks = 84 periods)
                self.scaler = StandardScaler()
                self.position = 0
                self.is_rf_fitted = False
                self.btc_rf = None
                self.vol_thresholds = {0.005: 0.0085, 0.01: 0.0075, 0.02: 0.010, 0.03: 0.015, float('inf'): 0.024}
                self.estimator_thresholds = {0.005: 55, 0.01: 45, 0.02: 35, 0.03: 45, float('inf'): 60}
                self.base_take_profit_multiplier = 11
                self.base_stop_loss_multiplier = 11
                self.take_profit_multipliers = {
                    0.005: self.base_take_profit_multiplier * 0.7,
                    0.01: self.base_take_profit_multiplier * 0.85,
                    0.02: self.base_take_profit_multiplier * 0.95,
                    0.03: self.base_take_profit_multiplier * 1.1,
                    float('inf'): self.base_take_profit_multiplier * 1.3
                }
                self.stop_loss_multipliers = {
                    0.005: self.base_stop_loss_multiplier * 0.75,
                    0.01: self.base_stop_loss_multiplier * 0.85,
                    0.02: self.base_stop_loss_multiplier * 0.95,
                    0.03: self.base_stop_loss_multiplier * 1,
                    float('inf'): self.base_stop_loss_multiplier * 1.2
                }
                self.entry_price = None
                self.stop_loss_cooldown = 0
                self.max_cooldown = 14

            def compute_atr(self, high, low, close, timeperiod=21, end_idx=None):
                if end_idx is None:
                    end_idx = len(close)
                atr = talib.ATR(high[:end_idx], low[:end_idx], close[:end_idx], timeperiod=timeperiod)
                return pd.Series(atr, index=self.data.index[:end_idx]).fillna(method='ffill').fillna(0)

            def hurst_exponent(self, window_data):
                try:
                    H, _, _ = compute_Hc(window_data, kind='price', simplified=True)
                    return H if not np.isnan(H) else 0.5
                except:
                    return 0.5

            def fdi(self, window_data):
                fdi = 2 - self.hurst_exponent(window_data)
                return fdi if not np.isnan(fdi) else 1.5

            def bollinger_bands(self, prices):
                upper, middle, lower = talib.BBANDS(prices, timeperiod=20)
                return (
                    pd.Series(upper).fillna(method='ffill').fillna(prices[0]),
                    pd.Series(middle).fillna(method='ffill').fillna(prices[0]),
                    pd.Series(lower).fillna(method='ffill').fillna(prices[0])
                )

            def entropy(self, window_data):
                returns = pd.Series(window_data).pct_change().dropna()
                if len(returns) < 20:
                    return 2.16
                hist, _ = np.histogram(returns[-20:], bins=20, density=True)
                return scipy_entropy(hist + 1e-10) if not np.isnan(scipy_entropy(hist + 1e-10)) else 2.16

            def macd(self, prices):
                macd, _, _ = talib.MACD(prices, fastperiod=50, slowperiod=100, signalperiod=20)
                return pd.Series(macd).fillna(method='ffill').fillna(0)

            def sma(self, prices):
                sma = talib.SMA(prices, timeperiod=28)
                return pd.Series(sma).fillna(method='ffill').fillna(prices[0])

            def ema(self, prices):
                ema = talib.EMA(prices, timeperiod=28)
                return pd.Series(ema).fillna(method='ffill').fillna(prices[0])

            def rsi(self, prices):
                rsi = talib.RSI(prices, timeperiod=21)
                return pd.Series(rsi).fillna(method='ffill').fillna(50)

            def obv(self, prices, volume):
                obv = talib.OBV(prices, volume)
                return pd.Series(obv).fillna(method='ffill').fillna(0)

            def stochastic(self, high, low, close):
                slowk, _ = talib.STOCH(high, low, close, fastk_period=14, slowk_period=3, slowd_period=3)
                return pd.Series(slowk).fillna(method='ffill').fillna(50)

            def vwap(self, high, low, close, volume):
                typical_price = (high + low + close) / 3
                vwap = np.cumsum(typical_price * volume) / np.cumsum(volume)
                return pd.Series(vwap).fillna(method='ffill').fillna(close[0])

            def velocity(self, param_series):
                return np.concatenate([[0], np.diff(param_series)]) if len(param_series) > 1 else np.array([0])

            def get_volatility_params(self, prices):
                if len(prices) < 2:
                    return 0.01, 35, self.base_take_profit_multiplier, self.base_stop_loss_multiplier, 60
                returns = pd.Series(prices).pct_change().dropna()
                vol = returns.std()
                position_pct = 50 + 30 * min(max((vol - 0.005) / (0.025 - 0.005), 0), 1)
                for vol_level in sorted(self.vol_thresholds.keys()):
                    if vol < vol_level:
                        return (
                            self.vol_thresholds[vol_level],
                            self.estimator_thresholds[vol_level],
                            self.take_profit_multipliers[vol_level],
                            self.stop_loss_multipliers[vol_level],
                            position_pct
                        )
                return (
                    self.vol_thresholds[float('inf')],
                    self.estimator_thresholds[float('inf')],
                    self.take_profit_multipliers[float('inf')],
                    self.stop_loss_multipliers[float('inf')],
                    position_pct
                )

            def compute_optimal_pattern(self, start_idx, end_idx):
                print(f"Computing optimal pattern with price indices: {start_idx} to {end_idx - 1}")
                prices = self.data['close'].iloc[start_idx:end_idx].values
                print(f"Number of prices in window: {len(prices)}")
                if len(prices) < 3:
                    return pd.Series(np.zeros(max(0, len(prices)-1)), index=self.data.index[start_idx:end_idx-1])
                returns = pd.Series(prices).pct_change().shift().dropna()
                if len(returns) == 0:
                    return pd.Series(np.zeros(len(prices)-1), index=self.data.index[start_idx:end_idx-1])
                threshold, _, _, _, _ = self.get_volatility_params(prices)
                pattern = np.where(returns > threshold, 1, np.where(returns < -threshold, -1, 0))
                return pd.Series(pattern, index=self.data.index[start_idx:start_idx + len(pattern)])

            def prepare_features(self, start_idx, end_idx):
                window_data = self.data.iloc[:end_idx-1] if start_idx > 0 else self.data.iloc[:end_idx]
                window_index = self.data.index[start_idx:end_idx]
                prices = window_data['close'].values
                if len(prices) < 2:
                    return np.zeros((len(window_index), 22))

                hurst_btc = [self.hurst_exponent(prices[max(0, i-20+1):i+1]) for i in range(max(0, len(prices) - len(window_index)), len(prices))]
                fdi_btc = [self.fdi(prices[max(0, i-20+1):i+1]) for i in range(max(0, len(prices) - len(window_index)), len(prices))]
                entropy_btc = [self.entropy(prices[max(0, i-20+1):i+1]) for i in range(max(0, len(prices) - len(window_index)), len(prices))]
                
                upper, middle, lower = self.bollinger_bands(prices)
                bb_width = (upper[-len(window_index):] - lower[-len(window_index):]) / middle[-len(window_index):]
                macd = self.macd(prices)[-len(window_index):]
                sma = self.sma(prices)[-len(window_index):]
                ema = self.ema(prices)[-len(window_index):]
                rsi = self.rsi(prices)[-len(window_index):]
                obv = self.obv(prices, window_data['volume'].values)[-len(window_index):]
                slowk = self.stochastic(
                    window_data.get('high_btc', window_data['close']).values,
                    window_data.get('low_btc', window_data['close']).values,
                    prices
                )[-len(window_index):]
                vwap = self.vwap(
                    window_data.get('high_btc', window_data['close']).values,
                    window_data.get('low_btc', window_data['close']).values,
                    prices,
                    window_data['volume'].values
                )[-len(window_index):]

                features = pd.DataFrame(index=window_index)
                features['hurst_btc'] = hurst_btc
                features['fdi_btc'] = fdi_btc
                features['bb_width_btc'] = bb_width
                features['entropy_btc'] = entropy_btc
                features['macd_btc'] = macd
                features['sma_btc'] = sma
                features['ema_btc'] = ema
                features['rsi_btc'] = rsi
                features['obv_btc'] = obv
                features['slowk_btc'] = slowk
                features['vwap_btc'] = vwap
                features['v_hurst_btc'] = self.velocity(hurst_btc)
                features['v_fdi_btc'] = self.velocity(fdi_btc)
                features['v_bb_width_btc'] = self.velocity(bb_width)
                features['v_entropy_btc'] = self.velocity(entropy_btc)
                features['v_macd_btc'] = self.velocity(macd)
                features['v_sma_btc'] = self.velocity(sma)
                features['v_ema_btc'] = self.velocity(ema)
                features['v_rsi_btc'] = self.velocity(rsi)
                features['v_obv_btc'] = self.velocity(obv)
                features['v_slowk_btc'] = self.velocity(slowk)
                features['v_vwap_btc'] = self.velocity(vwap)

                return self.scaler.fit_transform(features.replace([np.inf, -np.inf], np.nan).fillna(0))

            def train_random_forest(self, start_idx, end_idx):
                features = self.prepare_features(start_idx, end_idx)
                pattern = self.compute_optimal_pattern(start_idx, end_idx)
                X, y = features[:len(pattern)], pattern.values
                if len(X) < 5 or len(np.unique(y)) < 2:
                    return False
                _, n_estimators, _, _, _ = self.get_volatility_params(self.data['close'].iloc[start_idx:end_idx].values)
                self.btc_rf = RandomForestClassifier(n_estimators=n_estimators, max_depth=6, random_state=19)
                self.btc_rf.fit(X, y)
                self.is_rf_fitted = True
                return True

            def mask_signals(self, raw_signals, pred_index):
                masked_signals = np.zeros_like(raw_signals)
                signals_df = pd.DataFrame(index=pred_index)
                prices = self.data['close'].loc[pred_index].values
                end_idx = self.data.index.get_loc(pred_index[-1]) + 1
                atr_values = self.compute_atr(
                    self.data.get('high_btc', self.data['close']).values,
                    self.data.get('low_btc', self.data['close']).values,
                    self.close,
                    timeperiod=21,
                    end_idx=end_idx
                ).loc[pred_index].values

                start_idx = self.data.index.get_loc(pred_index[0])
                window_prices = self.data['close'].iloc[max(0, start_idx - self.t_recalc):end_idx].values
                _, _, take_profit_mult, stop_loss_mult, _ = self.get_volatility_params(window_prices) if len(window_prices) >= 2 else (0.01, 35, self.base_take_profit_multiplier, self.base_stop_loss_multiplier, 60)

                for i in range(len(raw_signals)):
                    current_price, current_atr = prices[i], atr_values[i]
                    take_profit, stop_loss = current_atr * take_profit_mult, current_atr * stop_loss_mult
                    if self.stop_loss_cooldown > 0:
                        self.stop_loss_cooldown -= 1
                        masked_signals[i] = 0
                        continue
                    if self.position == 1:
                        if current_price >= self.entry_price + take_profit or current_price <= self.entry_price - stop_loss:
                            masked_signals[i] = -1
                            self.position, self.entry_price, self.stop_loss_cooldown = 0, None, self.max_cooldown if current_price <= self.entry_price - stop_loss else 0
                    elif self.position == -1:
                        if current_price <= self.entry_price - take_profit or current_price >= self.entry_price + stop_loss:
                            masked_signals[i] = 1
                            self.position, self.entry_price, self.stop_loss_cooldown = 0, None, self.max_cooldown if current_price >= self.entry_price + stop_loss else 0
                    if self.position == 0 and masked_signals[i] == 0:
                        if raw_signals[i] == 1:
                            masked_signals[i], self.position, self.entry_price = 1, 1, current_price
                        elif raw_signals[i] == -1:
                            masked_signals[i], self.position, self.entry_price = -1, -1, current_price
                    elif self.position == 1 and raw_signals[i] == -1 and masked_signals[i] == 0:
                        masked_signals[i], self.position, self.entry_price = -1, 0, None
                    elif self.position == -1 and raw_signals[i] == 1 and masked_signals[i] == 0:
                        masked_signals[i], self.position, self.entry_price = 1, 0, None

                signals_df['buy_btc'] = masked_signals == 1
                signals_df['sell_btc'] = masked_signals == -1
                return signals_df

            def compute_signals(self):
                self.signals['buy_btc'] = False
                self.signals['sell_btc'] = False
                self.position = 0
                self.stop_loss_cooldown = 0

                initial_end_idx = min(self.t_recalc, len(self.data))
                if initial_end_idx > 1 and self.train_random_forest(0, initial_end_idx):
                    pred_end_idx = min(initial_end_idx + self.t_recalc, len(self.data))
                    pred_features = self.prepare_features(initial_end_idx, pred_end_idx)
                    pred_index = self.data.index[initial_end_idx:initial_end_idx + len(pred_features)]
                    btc_signals = self.btc_rf.predict(pred_features)
                    self.signals.loc[pred_index, ['buy_btc', 'sell_btc']] = self.mask_signals(btc_signals, pred_index)

                for i in range(self.t_recalc, len(self.data), self.t_recalc):
                    start_idx, end_idx = i - self.t_recalc, i
                    pred_start_idx, pred_end_idx = i, min(i + self.t_recalc, len(self.data))
                    if end_idx - start_idx >= 5 and self.train_random_forest(start_idx, end_idx):
                        pred_features = self.prepare_features(pred_start_idx, pred_end_idx)
                        pred_index = self.data.index[pred_start_idx:pred_start_idx + len(pred_features)]
                        btc_signals = self.btc_rf.predict(pred_features)
                        self.signals.loc[pred_index, ['buy_btc', 'sell_btc']] = self.mask_signals(btc_signals, pred_index)

                last_start_idx = (len(self.data) // self.t_recalc) * self.t_recalc
                if last_start_idx < len(self.data) and self.is_rf_fitted:
                    pred_features = self.prepare_features(last_start_idx, len(self.data))
                    pred_index = self.data.index[last_start_idx:last_start_idx + len(pred_features)]
                    btc_signals = self.btc_rf.predict(pred_features)
                    self.signals.loc[pred_index, ['buy_btc', 'sell_btc']] = self.mask_signals(btc_signals, pred_index)

        class Backtest:
            def __init__(self, strategy):
                self.strategy = strategy
                self.data = strategy.data
                self.signals = strategy.signals
                self.initial_capital = 10000  # Assuming USD, adjust if prices are in different units
                self.fee = 0.001
                self.capital = self.initial_capital
                self.btc_position = 0
                self.portfolio_value = []

            def compute_metrics(self):
                returns = pd.Series(self.portfolio_value).pct_change().dropna()
                total_return = (self.portfolio_value[-1] - self.initial_capital) / self.initial_capital
                sharpe_ratio = np.mean(returns) / np.std(returns) * np.sqrt(252 * 6) if np.std(returns) > 0 else 0  # 6 periods/day for 4h data
                drawdowns = pd.Series(self.portfolio_value).cummax() - self.portfolio_value
                max_drawdown = drawdowns.max() / pd.Series(self.portfolio_value).cummax().max() if drawdowns.max() > 0 else 0
                trades = self.output_data['signal'].diff().abs().sum() / 2
                wins = len(self.output_data[(self.output_data['signal'] == 1) & (self.output_data['close'].shift(-1) > self.output_data['close'])] +
                          self.output_data[(self.output_data['signal'] == -1) & (self.output_data['close'].shift(-1) < self.output_data['close'])])
                win_rate = wins / trades if trades > 0 else 0
                return {
                    'total_return': total_return,
                    'sharpe_ratio': sharpe_ratio,
                    'max_drawdown': max_drawdown,
                    'win_rate': win_rate,
                    'trades': trades
                }

            def run(self):
                self.output_data = pd.DataFrame(index=self.data.index)
                self.output_data['datetime'] = self.data['datetime']
                self.output_data['open'] = self.data.get('open_btc', self.data['close'])
                self.output_data['high'] = self.data.get('high_btc', self.data['close'])
                self.output_data['low'] = self.data.get('low_btc', self.data['close'])
                self.output_data['close'] = self.data['close']
                self.output_data['volume'] = self.data.get('volume', 0)
                self.output_data['signal'] = 0
                self.output_data['trade_type'] = TradeType.HOLD.value
                self.output_data['position'] = 60.0

                for i in range(1, len(self.data)):
                    btc_price = self.data['close'].iloc[i]
                    window_prices = self.data['close'].iloc[max(0, i - self.strategy.t_recalc):i + 1].values
                    _, _, _, _, position_pct = self.strategy.get_volatility_params(window_prices)
                    self.output_data.loc[self.data.index[i], 'position'] = position_pct

                    if self.signals['buy_btc'].iloc[i] and self.btc_position == 0 and self.capital > 0:
                        btc_buy = self.capital * (1 - self.fee) / btc_price
                        self.btc_position = btc_buy
                        self.capital -= btc_buy * btc_price
                        self.output_data.loc[self.data.index[i], 'signal'] = 1
                        self.output_data.loc[self.data.index[i], 'trade_type'] = TradeType.LONG.value
                    elif self.signals['sell_btc'].iloc[i] and self.btc_position == 0 and self.capital > 0:
                        btc_sell = self.capital * (1 - self.fee) / btc_price
                        self.btc_position = -btc_sell
                        self.capital += btc_sell * btc_price
                        self.output_data.loc[self.data.index[i], 'signal'] = -1
                        self.output_data.loc[self.data.index[i], 'trade_type'] = TradeType.SHORT.value
                    elif self.signals['sell_btc'].iloc[i] and self.btc_position > 0:
                        self.capital += self.btc_position * btc_price * (1 - self.fee)
                        self.btc_position = 0
                        self.output_data.loc[self.data.index[i], 'signal'] = -1
                        self.output_data.loc[self.data.index[i], 'trade_type'] = TradeType.CLOSE.value
                    elif self.signals['buy_btc'].iloc[i] and self.btc_position < 0:
                        cost = abs(self.btc_position) * btc_price * (1 + self.fee)
                        self.capital -= cost
                        self.btc_position = 0
                        self.output_data.loc[self.data.index[i], 'signal'] = 1
                        self.output_data.loc[self.data.index[i], 'trade_type'] = TradeType.CLOSE.value

                    portfolio_val = self.capital + (self.btc_position * btc_price)
                    self.portfolio_value.append(portfolio_val)
                    print(f"Step {i}: btc_price={btc_price}, btc_position={self.btc_position}, capital={self.capital}, portfolio_value={portfolio_val}")

                self.portfolio_value = [self.initial_capital] + self.portfolio_value
                metrics = self.compute_metrics()
                print(f"Backtest completed: {metrics}")
                return self.output_data

        strategy = TradingStrategy(data)
        strategy.compute_signals()
        backtest = Backtest(strategy)
        return backtest.run()

# Example usage
if __name__ == "__main__":
    data = pd.DataFrame({
        'datetime': pd.date_range('2023-01-01', periods=250, freq='4H'),
        'close': np.random.random(250) * 100 + 100,  # Prices between 100 and 200
        'volume': np.random.random(250) * 1000
    }).set_index('datetime')
    
    strategy = Strategy()
    result = strategy.run(data)