# Import libraries
import os
import uuid
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Categorical
from datetime import datetime
from dateutil.relativedelta import relativedelta
from collections import deque
import random
from untrade.client import Client

# Suppress warnings
import warnings
warnings.filterwarnings("ignore")

# Set a seed value for reproducibility
np.random.seed(1)
torch.manual_seed(1)

# Define LSTM-based Actor and Critic Networks
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim=128):
        super(Actor, self).__init__()
        self.lstm = nn.LSTM(state_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, action_dim)

    def forward(self, state):
        h_lstm, _ = self.lstm(state)
        action_probs = torch.softmax(self.fc(h_lstm[:, -1, :]), dim=-1)
        return action_probs

class Critic(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim=128):
        super(Critic, self).__init__()
        self.lstm = nn.LSTM(state_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, action_dim)

    def forward(self, state):
        h_lstm, _ = self.lstm(state)
        q_values = self.fc(h_lstm[:, -1, :])
        return q_values

# Define SAC Agent
class SACAgent:
    def __init__(self, state_dim, action_dim, hidden_dim=128, lr=1e-3, gamma=0.99, tau=0.005, alpha=0.2):
        self.actor = Actor(state_dim, action_dim, hidden_dim)
        self.critic1 = Critic(state_dim, action_dim, hidden_dim)
        self.critic2 = Critic(state_dim, action_dim, hidden_dim)
        self.target_critic1 = Critic(state_dim, action_dim, hidden_dim)
        self.target_critic2 = Critic(state_dim, action_dim, hidden_dim)
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=lr)
        self.critic1_optimizer = optim.Adam(self.critic1.parameters(), lr=lr)
        self.critic2_optimizer = optim.Adam(self.critic2.parameters(), lr=lr)
        self.gamma = gamma
        self.tau = tau
        self.alpha = alpha
        self.replay_buffer = deque(maxlen=1000000)

    def select_action(self, state):
        state = torch.FloatTensor(state).unsqueeze(0)
        action_probs = self.actor(state)
        action = torch.multinomial(action_probs, 1).item()
        return action

    def update(self, batch_size):
        if len(self.replay_buffer) < batch_size:
            return
        batch = random.sample(self.replay_buffer, batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        states = torch.FloatTensor(states)
        actions = torch.LongTensor(actions)
        rewards = torch.FloatTensor(rewards)
        next_states = torch.FloatTensor(next_states)
        dones = torch.FloatTensor(dones)

        # Update Critic Networks
        with torch.no_grad():
            next_action_probs = self.actor(next_states)
            next_q1 = self.target_critic1(next_states)
            next_q2 = self.target_critic2(next_states)
            next_q = torch.min(next_q1, next_q2)
            next_q = (next_action_probs * (next_q - self.alpha * torch.log(next_action_probs))).sum(dim=1)
            target_q = rewards + (1 - dones) * self.gamma * next_q

        current_q1 = self.critic1(states).gather(1, actions.unsqueeze(1))
        current_q2 = self.critic2(states).gather(1, actions.unsqueeze(1))
        critic1_loss = nn.MSELoss()(current_q1.squeeze(), target_q)
        critic2_loss = nn.MSELoss()(current_q2.squeeze(), target_q)

        self.critic1_optimizer.zero_grad()
        critic1_loss.backward()
        self.critic1_optimizer.step()

        self.critic2_optimizer.zero_grad()
        critic2_loss.backward()
        self.critic2_optimizer.step()

        # Update Actor Network
        action_probs = self.actor(states)
        q1 = self.critic1(states)
        q2 = self.critic2(states)
        q = torch.min(q1, q2)
        actor_loss = (action_probs * (self.alpha * torch.log(action_probs) - q).sum(dim=1).mean())
        
        self.actor_optimizer.zero_grad()

        actor_loss.backward()

        self.actor_optimizer.step()

        # Update Target Networks
        for param, target_param in zip(self.critic1.parameters(), self.target_critic1.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

        for param, target_param in zip(self.critic2.parameters(), self.target_critic2.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

# Ensemble of SAC Agents
class EnsembleSAC:
    def __init__(self, num_agents, state_dim, action_dim, hidden_dim=128, lr=1e-3, gamma=0.99, tau=0.005, alpha=0.2):
        self.agents = [SACAgent(state_dim, action_dim, hidden_dim, lr, gamma, tau, alpha) for _ in range(num_agents)]

    def select_action(self, state):
        actions = [agent.select_action(state) for agent in self.agents]
        return np.mean(actions)  # Example: average the actions

    def update(self, batch_size):
        for agent in self.agents:
            agent.update(batch_size)

# Define the process_data function
def process_data(data_incoming):
    """
    Processes market data by filtering, handling missing values, and generating technical indicators/signals.

    Parameters:
        data_incoming (pd.DataFrame): Input market data with required columns: 
                                      'datetime', 'close', 'high', 'low', 'volume'.

    Returns:
        pd.DataFrame: Processed data containing essential columns, indicators, and trading signals.
    """
    def load_data(df, start_datetime, end_datetime, drop_columns=None):
        data = df.copy()

        if drop_columns:
            existing_cols = [col for col in drop_columns if col in data.columns]
            data.drop(existing_cols, axis=1, inplace=True)
        
        data['datetime'] = pd.to_datetime(data['datetime'], format='%Y-%m-%d %H:%M:%S') 
        data.set_index('datetime', inplace=True)
        data = data.loc[start_datetime:end_datetime].copy()
        
        essential_columns = ['close', 'high', 'low', 'volume']
        for col in essential_columns:
            if col not in data.columns:
                raise ValueError(f"Missing essential column: '{col}' in the data.")
        
        data[essential_columns] = data[essential_columns].fillna(method='ffill')
        
        data['MA7'] = data['close'].rolling(window=7).mean()
        data['MA14'] = data['close'].rolling(window=14).mean()
        data['MA_Signal'] = 0
        data.loc[data['MA7'] > data['MA14'], 'MA_Signal'] = 1
        data.loc[data['MA7'] < data['MA14'], 'MA_Signal'] = -1

        data['Aroon_Up'] = 100 * (14 - data['high'].rolling(window=15).apply(lambda x: x.argmax())) / 14
        data['Aroon_Down'] = 100 * (14 - data['low'].rolling(window=15).apply(lambda x: x.argmin())) / 14
        data['Aroon_Signal'] = 0
        data.loc[data['Aroon_Up'] > data['Aroon_Down'], 'Aroon_Signal'] = 1
        data.loc[data['Aroon_Up'] < data['Aroon_Down'], 'Aroon_Signal'] = -1

        def rsi(data, window):
            delta = data.diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
            rs = gain / loss
            return 100 - (100 / (1 + rs))

        data['RSI_14'] = rsi(data['close'], 14)
        data['RSI_Signal'] = 0
        data.loc[data['RSI_14'] > 75, 'RSI_Signal'] = 1
        data.loc[data['RSI_14'] < 35, 'RSI_Signal'] = -1

        data['returns'] = np.log(data.close / data.close.shift(1))

        data['EMA7'] = data['close'].ewm(span=7, adjust=False).mean()
        data['EMA14'] = data['close'].ewm(span=14, adjust=False).mean()
        data['EMA28'] = data['close'].ewm(span=28, adjust=False).mean()
        data['EMA_Signal'] = 0
        data.loc[(data['EMA7'] > data['EMA14']) & (data['EMA14'] > data['EMA28']), 'EMA_Signal'] = 1
        data.loc[(data['EMA7'] < data['EMA14']) & (data['EMA14'] < data['EMA28']), 'EMA_Signal'] = -1
        
        data['EMA_Signal'] = data['EMA_Signal'].astype(int)
        data['pct_change'] = data['close'].pct_change(periods=1).fillna(0) * 100
        data.dropna(subset=['EMA7', 'EMA14', 'EMA28'], inplace=True)
        data.dropna(inplace=True)
        
        signal_columns = ['Aroon_Signal', 'RSI_Signal', 'EMA_Signal']
        data[signal_columns] = data[signal_columns].astype(int)
        
        return data

    train_start_datetime = '2020-01-01'
    train_end_datetime = '2022-12-31'
    test_start_datetime = '2023-01-01'
    test_end_datetime = '2024-01-01'

    train_btc_data = pd.read_csv("C:\\Users\\super\\Desktop\\Zelta\\untrade-sdk\\examples\\ETHUSDT_1h.csv")
    train_data = load_data(train_btc_data, train_start_datetime, train_end_datetime, drop_columns=['Unnamed: 0'])
    test_data = load_data(data_incoming, test_start_datetime, test_end_datetime, drop_columns=['Unnamed: 0'])

    final_data = pd.concat([train_data, test_data])
    return final_data

# Main Function
def main():
    # Load and preprocess data
    data = pd.read_csv("C:\\Users\\super\\Desktop\\Zelta\\untrade-sdk\\examples\\ETHUSDT_1h.csv")
    data = process_data(data)

    # Initialize ensemble of SAC agents
    state_dim = 5  # Adjust based on your state representation
    action_dim = 5  # Adjust based on your action space
    ensemble_sac = EnsembleSAC(num_agents=5, state_dim=state_dim, action_dim=action_dim)

    # Training loop
    for episode in range(1000):
        state = data.iloc[0].values  # Adjust based on your state representation
        done = False
        total_reward = 0

        while not done:
            action = ensemble_sac.select_action(state)
            next_state, reward, done = env.step(action)  # Adjust based on your environment
            ensemble_sac.update(batch_size=64)
            total_reward += reward
            state = next_state

        print(f"Episode {episode}, Total Reward: {total_reward}")

if __name__ == "__main__":
    main()