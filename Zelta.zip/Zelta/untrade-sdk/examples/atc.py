import os
import uuid
from untrade.client import Client
import numpy as np
import pandas as pd
from datetime import datetime
from dateutil.relativedelta import relativedelta
import tensorflow as tf
from tensorflow.keras import layers
import warnings
warnings.filterwarnings("ignore")

# Set seeds for reproducibility
np.random.seed(1)
tf.random.set_seed(1)

def hurst_exponent(timeseries, max_lag=100):
    lags = range(2, max_lag)
    rs_values = []
    for lag in lags:
        differences = np.diff(timeseries)
        n = len(timeseries) - lag
        if n < 2:
            continue
        sub_series = [timeseries[i:i+lag] for i in range(0, len(timeseries)-lag+1, lag)]
        if not sub_series:
            continue
        rs = []
        for series in sub_series:
            mean = np.mean(series)
            deviations = series - mean
            range_val = np.max(series) - np.min(series)
            std_dev = np.std(deviations)
            if std_dev == 0:
                continue
            rs.append(range_val / std_dev)
        rs_values.append(np.mean(rs))
    if len(rs_values) < 2:
        return 0.5
    log_lags = np.log(lags[:len(rs_values)])
    log_rs = np.log(rs_values)
    poly = np.polyfit(log_lags, log_rs, 1)
    return poly[0]

def process_data(data_incoming):
    def load_data(df, start_datetime, end_datetime, drop_columns=None):
        data = df.copy()
        if drop_columns:
            existing_cols = [col for col in drop_columns if col in data.columns]
            data.drop(existing_cols, axis=1, inplace=True)
        data['datetime'] = pd.to_datetime(data['datetime'], format='%Y-%m-%d %H:%M:%S')
        data.set_index('datetime', inplace=True)
        data = data.loc[start_datetime:end_datetime].copy()
        essential_columns = ['close', 'high', 'low', 'volume']
        for col in essential_columns:
            if col not in data.columns:
                raise ValueError(f"Missing essential column: '{col}' in the data.")
        data[essential_columns] = data[essential_columns].fillna(method='ffill')
        
        data['MA7'] = data['close'].rolling(window=7).mean()
        data['MA14'] = data['close'].rolling(window=14).mean()
        data['MA_Signal'] = 0
        data.loc[data['MA7'] > data['MA14'], 'MA_Signal'] = 1
        data.loc[data['MA7'] < data['MA14'], 'MA_Signal'] = -1

        data['Aroon_Up'] = 100 * (14 - data['high'].rolling(window=15).apply(lambda x: x.argmax())) / 14
        data['Aroon_Down'] = 100 * (14 - data['low'].rolling(window=15).apply(lambda x: x.argmin())) / 14
        data['Aroon_Signal'] = 0
        data.loc[data['Aroon_Up'] > data['Aroon_Down'], 'Aroon_Signal'] = 1
        data.loc[data['Aroon_Up'] < data['Aroon_Down'], 'Aroon_Signal'] = -1

        def rsi(data, window):
            delta = data.diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
            rs = gain / loss
            return 100 - (100 / (1 + rs))

        data['RSI_14'] = rsi(data['close'], 14)
        data['RSI_Signal'] = 0
        data.loc[data['RSI_14'] > 75, 'RSI_Signal'] = 1
        data.loc[data['RSI_14'] < 35, 'RSI_Signal'] = -1

        data['returns'] = np.log(data.close / data.close.shift(1))

        data['EMA7'] = data['close'].ewm(span=7, adjust=False).mean()
        data['EMA14'] = data['close'].ewm(span=14, adjust=False).mean()
        data['EMA28'] = data['close'].ewm(span=28, adjust=False).mean()
        data['EMA_Signal'] = 0
        data.loc[(data['EMA7'] > data['EMA14']) & (data['EMA14'] > data['EMA28']), 'EMA_Signal'] = 1
        data.loc[(data['EMA7'] < data['EMA14']) & (data['EMA14'] < data['EMA28']), 'EMA_Signal'] = -1
        
        data['Hurst'] = pd.Series(data['close']).rolling(window=100).apply(hurst_exponent, raw=True)
        data['Hurst_Signal'] = 0
        data.loc[data['Hurst'] > 0.65, 'Hurst_Signal'] = 1
        data.loc[data['Hurst'] < 0.35, 'Hurst_Signal'] = -1
        
        data['pct_change'] = data['close'].pct_change(periods=1).fillna(0) * 100
        
        data.dropna(subset=['EMA7', 'EMA14', 'EMA28', 'Hurst'], inplace=True)
        data.dropna(inplace=True)
        
        signal_columns = ['Aroon_Signal', 'RSI_Signal', 'EMA_Signal', 'Hurst_Signal']
        data[signal_columns] = data[signal_columns].astype(int)
        
        return data

    train_start_datetime = '2020-01-01'
    train_end_datetime = '2020-02-01'
    test_start_datetime = '2020-03-01'
    test_end_datetime = '2020-12-31'

    train_btc_data = pd.read_csv("C:\\Users\\super\\Desktop\\Zelta\\untrade-sdk\\examples\\ETHUSDT_1h.csv")
    train_data = load_data(train_btc_data, train_start_datetime, train_end_datetime, drop_columns=['Unnamed: 0'])
    test_data = load_data(data_incoming, test_start_datetime, test_end_datetime, drop_columns=['Unnamed: 0'])

    final_data = pd.concat([train_data, test_data])
    return final_data

def strat(data_incoming):
    train_start_datetime = '2020-01-01'
    train_end_datetime = '2020-02-01'
    test_start_datetime = '2020-03-01'
    test_end_datetime = '2020-12-31'
    train_data = data_incoming.loc[train_start_datetime:train_end_datetime].copy()
    test_data = data_incoming.loc[test_start_datetime:test_end_datetime].copy()
    
    train_prices = train_data['close'].values 
    train_aroon_signal = train_data['Aroon_Signal'].values
    train_rsi_signal = train_data['RSI_Signal'].values
    train_ema_signal = train_data['EMA_Signal'].values
    train_hurst_signal = train_data['Hurst_Signal'].values
    train_pct_change = train_data['pct_change'].values

    test_prices = test_data['close'].values 
    test_aroon_signal = test_data['Aroon_Signal'].values
    test_rsi_signal = test_data['RSI_Signal'].values
    test_ema_signal = test_data['EMA_Signal'].values
    test_hurst_signal = test_data['Hurst_Signal'].values
    test_pct_change = test_data['pct_change'].values

    MIN_TRADE_AMOUNT = 5000     
    COMMISSION_RATE = 0.0015   
    MAX_SHORT_POSITION = 0.75  
    STOP_LOSS_PERCENT = 0.05 

    class TradingEnvironment:
        def __init__(self, actual_prices, aroon_signal, rsi_signal, ema_signal, hurst_signal, pct_change):
            self.actual_prices = actual_prices
            self.aroon_signal = aroon_signal
            self.rsi_signal = rsi_signal
            self.ema_signal = ema_signal
            self.hurst_signal = hurst_signal
            self.pct_change = pct_change
            self.n_steps = len(actual_prices)
            self.current_step = 0
            self.position = 0         
            self.balance = 10000.0    
            self.net_worth = self.balance
            self.initial_balance = self.balance
            self.trades = []
            self.entry_price = 0.0
            self.holdings = 0.0        
            self.history = [self.net_worth]
            self.last_worth = self.balance

        def _get_observation(self):
            return np.array([
                self.aroon_signal[self.current_step],
                self.rsi_signal[self.current_step],
                self.ema_signal[self.current_step],
                self.hurst_signal[self.current_step],
                self.position,
                self.pct_change[self.current_step]
            ], dtype=np.float32)
        
        def reset(self):
            self.current_step = 0
            self.position = 0
            self.balance = self.initial_balance
            self.net_worth = self.balance
            self.trades = []
            self.entry_price = 0.0
            self.holdings = 0.0
            self.history = [self.net_worth]
            self.last_worth = self.balance
            return self._get_observation()

        def step(self, action):
            actual_price = self.actual_prices[self.current_step]
            done = False
            reward = 0.0  
            traded = 0
            if action == 1 and (self.position == -1 or self.position == 0):
                if self.position == -1:
                    traded = 1
                    gross_purchase = -self.holdings * actual_price
                    commission_exit = gross_purchase * COMMISSION_RATE
                    total_cost = gross_purchase + commission_exit
                    self.balance -= total_cost  
                    profit = (self.balance + self.holdings * actual_price) - self.last_worth
                    if self.balance < MIN_TRADE_AMOUNT:
                        self.balance = 0.0
                        self.holdings = 0.0
                        self.position = 0
                        reward += -100000000
                        done = True
                        return self._get_observation(), reward, done
                    else:
                        self.holdings = 0.0
                        self.position = 0 
                        reward += profit
                    self.net_worth = self.balance + self.holdings * actual_price
                if self.balance < MIN_TRADE_AMOUNT:
                    reward -= 100000000
                    done = True
                    return self._get_observation(), reward, done
                if self.position == 0:
                    self.last_worth = self.net_worth
                    total_cost = self.balance
                    commission = total_cost * COMMISSION_RATE 
                    investment_amount = total_cost - commission
                    self.holdings = investment_amount / actual_price
                    self.position = 1 
                    self.entry_price = actual_price
                    self.balance = 0.0  
                    if traded:
                        self.trades.append({'step': self.current_step, 'trade_type': 'short_reversal', 'price': actual_price, 'commission': commission, 'signals': 2})
                    else:
                        self.trades.append({'step': self.current_step, 'trade_type': 'long', 'price': actual_price, 'commission': commission, 'signals': 1})
                    traded = 2
                    reward -= commission 

            elif action == 2 and self.position == 1:
                gross_sale = self.holdings * actual_price
                commission = gross_sale * COMMISSION_RATE
                net_sale = gross_sale - commission
                self.balance += net_sale 
                self.holdings = 0.0
                profit = (self.balance + self.holdings * actual_price) - self.last_worth
                self.position = 0 
                self.trades.append({'step': self.current_step, 'trade_type': 'long_close', 'price': actual_price, 'commission': commission, 'signals': -1})
                traded = 1
                reward += profit

            elif action == 3 and (self.position == 1 or self.position == 0):
                if self.position == 1:
                    traded = 1
                    gross_sale = self.holdings * actual_price
                    commission = gross_sale * COMMISSION_RATE
                    net_sale = gross_sale - commission
                    self.balance += net_sale  
                    self.holdings = 0.0
                    profit = (self.balance + self.holdings * actual_price) - self.last_worth
                    self.position = 0 
                    reward += profit
                    self.net_worth = self.balance + self.holdings * actual_price
                if self.balance < MIN_TRADE_AMOUNT:
                    reward -= 100000000
                    done = True
                    return self._get_observation(), reward, done
                if self.position == 0 and self.balance > MIN_TRADE_AMOUNT:
                    self.last_worth = self.net_worth
                    short_value = self.balance * MAX_SHORT_POSITION
                    gross_proceeds = short_value
                    commission_entry = gross_proceeds * COMMISSION_RATE
                    net_proceeds = gross_proceeds - commission_entry
                    units_to_short = gross_proceeds / actual_price 
                    self.holdings = -units_to_short 
                    self.position = -1 
                    self.entry_price = actual_price
                    self.balance += net_proceeds  
                    if traded:
                        self.trades.append({'step': self.current_step, 'trade_type': 'long_reversal', 'price': actual_price, 'commission': commission_entry, 'signals': -2})
                    else:
                        self.trades.append({'step': self.current_step, 'trade_type': 'short', 'price': actual_price, 'commission': commission_entry, 'signals': -1})
                    traded = 2
                    reward -= commission_entry 

            elif action == 4 and self.position == -1:
                traded = 1
                gross_purchase = -self.holdings * actual_price
                commission_exit = gross_purchase * COMMISSION_RATE
                total_cost = gross_purchase + commission_exit
                self.balance -= total_cost 
                profit = (self.balance + self.holdings * actual_price) - self.last_worth
                if self.balance < MIN_TRADE_AMOUNT:
                    self.balance = 0.0
                    self.holdings = 0.0
                    self.position = 0
                    self.trades.append({'step': self.current_step, 'trade_type': 'short_close', 'price': actual_price, 'commission': commission_exit, 'signals': 1})
                    reward += -100000000
                    done = True
                    return self._get_observation(), reward, done
                else:
                    self.holdings = 0.0
                    self.position = 0 
                    self.trades.append({'step': self.current_step, 'trade_type': 'short_close', 'price': actual_price, 'commission': commission_exit, 'signals': 1})
                    reward += profit

            if self.position == 1 and actual_price <= self.entry_price * (1 - STOP_LOSS_PERCENT):
                traded = 1
                gross_sale = self.holdings * actual_price
                commission = gross_sale * COMMISSION_RATE
                net_sale = gross_sale - commission
                self.balance += net_sale  
                self.holdings = 0.0
                profit = (self.balance + self.holdings * actual_price) - self.last_worth
                self.position = 0 
                self.trades.append({'step': self.current_step, 'trade_type': 'long_close', 'price': actual_price, 'commission': commission, 'signals': -1})
                reward += profit

            elif self.position == -1 and actual_price >= self.entry_price * (1 + STOP_LOSS_PERCENT):
                traded = 1
                gross_purchase = -self.holdings * actual_price
                commission_exit = gross_purchase * COMMISSION_RATE
                total_cost = gross_purchase + commission_exit
                self.balance -= total_cost 
                profit = (self.balance + self.holdings * actual_price) - self.last_worth
                if self.balance < MIN_TRADE_AMOUNT:
                    self.balance = 0.0
                    self.holdings = 0.0
                    self.position = 0
                    self.trades.append({'step': self.current_step, 'trade_type': 'short_close', 'price': actual_price, 'commission': commission_exit, 'signals': 1})
                    reward += -100000000
                    done = True
                    return self._get_observation(), reward, done
                else:
                    self.holdings = 0.0
                    self.position = 0 
                    self.trades.append({'step': self.current_step, 'trade_type': 'short_close', 'price': actual_price, 'commission': commission_exit, 'signals': 1})
                    reward += profit
        
            else:
                if traded == 0:
                    self.trades.append({'step': self.current_step, 'trade_type': ' ', 'price': actual_price, 'commission': 0, 'signals': 0})
                if self.position != 0:
                    reward += (self.balance + self.holdings * actual_price) - self.net_worth
                else:
                    if self.current_step > 0:
                        reward -= (abs(actual_price - self.actual_prices[self.current_step-1])) * self.net_worth / self.actual_prices[self.current_step-1]

            self.current_step += 1

            if self.current_step >= self.n_steps - 1:
                done = True
                if self.position == 1:
                    self.trades.append({'step': self.current_step, 'trade_type': 'long_close', 'price': actual_price, 'commission': 0, 'signals': -1 * self.position})
                elif self.position == -1:
                    self.trades.append({'step': self.current_step, 'trade_type': 'short_close', 'price': actual_price, 'commission': 0, 'signals': -1 * self.position})
                else:
                    self.trades.append({'step': self.current_step, 'trade_type': ' ', 'price': actual_price, 'commission': 0, 'signals': 0})

            self.net_worth = self.balance + self.holdings * actual_price
            self.history.append(self.net_worth)
            self.max_net_worth = max(getattr(self, 'max_net_worth', self.initial_balance), self.net_worth)

            obs = self._get_observation()
            return obs, reward, done

    # A2C Model
    class A2CModel:
        def __init__(self, state_size, action_size):
            self.state_size = state_size
            self.action_size = action_size
            self.actor = self._build_actor()
            self.critic = self._build_critic()
            self.actor_optimizer = tf.keras.optimizers.Adam(learning_rate=0.001)
            self.critic_optimizer = tf.keras.optimizers.Adam(learning_rate=0.002)
            self.gamma = 0.95  # Discount factor

        def _build_actor(self):
            inputs = layers.Input(shape=(self.state_size,))
            x = layers.Dense(64, activation='relu')(inputs)
            x = layers.Dense(32, activation='relu')(x)
            outputs = layers.Dense(self.action_size, activation='softmax')(x)
            return tf.keras.Model(inputs, outputs)

        def _build_critic(self):
            inputs = layers.Input(shape=(self.state_size,))
            x = layers.Dense(64, activation='relu')(inputs)
            x = layers.Dense(32, activation='relu')(x)
            outputs = layers.Dense(1)(x)
            return tf.keras.Model(inputs, outputs)

        def train(self, states, actions, rewards, next_states, dones):
            states = np.array(states, dtype=np.float32)
            next_states = np.array(next_states, dtype=np.float32)
            rewards = np.array(rewards, dtype=np.float32)
            dones = np.array(dones, dtype=np.float32)

            with tf.GradientTape() as actor_tape, tf.GradientTape() as critic_tape:
                # Critic loss
                values = self.critic(states, training=True)
                next_values = self.critic(next_states, training=True)
                td_targets = rewards + self.gamma * next_values * (1 - dones)
                critic_loss = tf.reduce_mean(tf.square(td_targets - values))

                # Actor loss
                action_probs = self.actor(states, training=True)
                action_log_probs = tf.math.log(tf.reduce_sum(action_probs * actions, axis=1))
                advantages = td_targets - values
                actor_loss = -tf.reduce_mean(action_log_probs * advantages)

            actor_grads = actor_tape.gradient(actor_loss, self.actor.trainable_variables)
            critic_grads = critic_tape.gradient(critic_loss, self.critic.trainable_variables)
            self.actor_optimizer.apply_gradients(zip(actor_grads, self.actor.trainable_variables))
            self.critic_optimizer.apply_gradients(zip(critic_grads, self.critic.trainable_variables))

        def get_action(self, state):
            state = np.expand_dims(state, axis=0).astype(np.float32)
            probs = self.actor(state, training=False).numpy()[0]
            return np.random.choice(self.action_size, p=probs)

    # Training
    state_size = 6  # Aroon, RSI, EMA, Hurst, position, pct_change
    action_size = 5  # Hold, Long, Close Long, Short, Close Short
    model = A2CModel(state_size, action_size)
    train_env = TradingEnvironment(
        actual_prices=train_prices,
        aroon_signal=train_aroon_signal,
        rsi_signal=train_rsi_signal,
        ema_signal=train_ema_signal,
        hurst_signal=train_hurst_signal,
        pct_change=train_pct_change,
    )

    episodes = 500
    print("Starting A2C Training...\n")
    for episode in range(episodes):
        state = train_env.reset()
        states, actions, rewards, next_states, dones = [], [], [], [], []
        total_reward = 0

        while True:
            action = model.get_action(state)
            one_hot_action = tf.keras.utils.to_categorical(action, num_classes=action_size)
            next_state, reward, done = train_env.step(action)

            states.append(state)
            actions.append(one_hot_action)
            rewards.append(reward)
            next_states.append(next_state)
            dones.append(done)
            total_reward += reward

            state = next_state

            if done:
                model.train(states, actions, rewards, next_states, dones)
                print(f"Episode {episode+1}/{episodes}, Total Reward: {total_reward:.2f}")
                break

    print("\nTraining Completed!\n")

    # Testing
    test_env = TradingEnvironment(
        actual_prices=test_prices,
        aroon_signal=test_aroon_signal,
        rsi_signal=test_rsi_signal,
        ema_signal=test_ema_signal,
        hurst_signal=test_hurst_signal,
        pct_change=test_pct_change,
    )
    state = test_env.reset()
    done = False
    total_reward = 0

    while not done:
        action = model.get_action(state)
        next_state, reward, done = test_env.step(action)
        total_reward += reward
        state = next_state

    print(f'\nFinal Net Worth on Testing Data: ${test_env.net_worth:.2f}')

    trades_df = pd.DataFrame(test_env.trades)
    test_data = test_data.reset_index()
    test_data = pd.concat([test_data, trades_df[['signals', 'trade_type']]], axis=1)
    return test_data

def perform_backtest(csv_file_path):
    client = Client()
    result = client.backtest(
        jupyter_id="team67_zelta_hpps",
        file_path=csv_file_path,
        leverage=1,
    )
    return result

def perform_backtest_large_csv(csv_file_path):
    client = Client()
    file_id = str(uuid.uuid4())
    chunk_size = 90 * 1024 * 1024
    total_size = os.path.getsize(csv_file_path)
    total_chunks = (total_size + chunk_size - 1) // chunk_size
    chunk_number = 0

    with open(csv_file_path, "rb") as f:
        while chunk_data := f.read(chunk_size):
            chunk_file_path = f"/tmp/{file_id}chunk{chunk_number}.csv"
            with open(chunk_file_path, "wb") as chunk_file:
                chunk_file.write(chunk_data)
            result = client.backtest(
                file_path=chunk_file_path,
                leverage=1,
                jupyter_id="team67_zelta_hpps",
                file_id=file_id,
                chunk_number=chunk_number,
                total_chunks=total_chunks,
            )
            for value in result:
                print(value)
            os.remove(chunk_file_path)
            chunk_number += 1
    return result

def main():
    print(f"Starting.....")
    data = pd.read_csv("C:\\Users\\super\\Desktop\\Zelta\\untrade-sdk\\examples\\ETHUSDT_1h.csv")
    data = process_data(data)
    print(f"Stage 1 : Complete")
    strategized_data = strat(data)
    print(f"Stage 2 : Complete")
    csv_file_path = "C:\\Users\\super\\Desktop\\Zelta\\untrade-sdk\\examples\\ETHUSDT_1h.csv"
    strategized_data.to_csv(csv_file_path, index=False)
    backtest_result = perform_backtest(csv_file_path)
    print(f"Stage 3 : Complete")
    last_value = None
    for value in backtest_result:
        last_value = value
    print(last_value)
    print("Trading Successfull")
if __name__ == "__main__":
    main()