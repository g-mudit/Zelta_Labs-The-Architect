import numpy as np
import pandas as pd
import gym
import random
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque

# === Data Preprocessing ===
def load_data(file_path):
    df = pd.read_csv(file_path)
    df['BuyLine'] = df['open'] + 0.5 * (df['high'] - df['low'])  # Dual Thrust Upper Breakout
    df['SellLine'] = df['open'] - 0.5 * (df['high'] - df['low'])  # Dual Thrust lower Breakout
    return df

# === Custom Gym Trading Environment ===
class TradingEnv(gym.Env):
    def __init__(self, df, initial_balance=500000, eta=0.01):
        super(TradingEnv, self).__init__()
        self.df = df
        self.index = 0
        self.balance = initial_balance
        self.position = 0  # 1: long, -1: short, 0: no position
        self.total_profit = 0
        self.done = False
        self.eta = eta  # Adaptation rate for Sharpe Ratio
        self.alpha = 0  # Moving avg of returns
        self.beta = 0   # Moving avg of squared returns
        self.transaction_cost = 0.0001  # 0.01% transaction fee
        self.slippage = 0.0002  # 0.02% price slippage

        self.observation_space = gym.spaces.Box(low=-np.inf, high=np.inf, shape=(6,))
        self.action_space = gym.spaces.Discrete(2)  # Buy (1), Sell (-1)

    def reset(self):
        self.index = 0
        self.balance = 500000
        self.position = 0
        self.total_profit = 0
        self.done = False
        return self._next_observation()

    def _next_observation(self):
        row = self.df.iloc[self.index]
        return np.array([row['open'], row['high'], row['low'], row['close'], row['BuyLine'], row['SellLine']])

    def _calculate_reward(self, price_change):
        """
        Computes reward based on the Differential Sharpe Ratio.
        """
        r_t = price_change - self.transaction_cost  # Net return after costs
        delta_alpha = self.eta * (r_t - self.alpha)
        delta_beta = self.eta * (r_t**2 - self.beta)

        self.alpha += delta_alpha
        self.beta += delta_beta

        if self.beta - self.alpha**2 > 0:
            dt = (self.beta * delta_alpha - 0.5 * self.alpha * delta_beta) / ((self.beta - self.alpha**2) ** 1.5)
        else:
            dt = 0  # Avoid division by zero

        return dt

    def step(self, action):
        row = self.df.iloc[self.index]
        reward = 0
        executed_price = row['close'] * (1 + self.slippage if action == 1 else 1 - self.slippage)

        if action == 1 and self.position == 0:  # open Long
            self.position = 1
            self.entry_price = executed_price
        elif action == -1 and self.position == 1:  # close Long
            price_change = executed_price - self.entry_price
            reward = self._calculate_reward(price_change)
            self.position = 0
            self.total_profit += price_change

        self.index += 1
        if self.index >= len(self.df) - 1:
            self.done = True

        return self._next_observation(), reward, self.done, {}

# === Actor-Critic Model with GRU ===
class ActorCritic(nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super(ActorCritic, self).__init__()
        self.gru = nn.GRU(input_dim, hidden_dim, batch_first=True)
        self.actor = nn.Linear(hidden_dim, 1)
        self.critic = nn.Linear(hidden_dim, 1)

    def forward(self, x):
        x, _ = self.gru(x)
        x = x[:, -1, :]
        action = torch.tanh(self.actor(x))  # Continuous action space
        value = self.critic(x)
        return action, value

# === iRDPG Agent ===
class iRDPG:
    def __init__(self, env, hidden_dim=64, lr=0.001, gamma=0.99):
        self.env = env
        self.model = ActorCritic(input_dim=6, hidden_dim=hidden_dim).to("cpu")
        self.target_model = ActorCritic(input_dim=6, hidden_dim=hidden_dim).to("cpu")
        self.optimizer = optim.Adam(self.model.parameters(), lr=lr)
        self.gamma = gamma
        self.buffer = deque(maxlen=10000)
        self.demo_buffer = deque(maxlen=5000)

    def select_action(self, state):
        state = torch.tensor(state, dtype=torch.float32).unsqueeze(0).unsqueeze(0)
        action, _ = self.model(state)
        return 1 if action.item() > 0 else -1

    def store_experience(self, experience, demo=False):
        if demo:
            self.demo_buffer.append(experience)
        else:
            self.buffer.append(experience)

    def train(self, batch_size=32):
        if len(self.buffer) < batch_size:
            return

        minibatch = random.sample(self.buffer, batch_size // 2) + random.sample(self.demo_buffer, batch_size // 2)
        states, actions, rewards, next_states = zip(*minibatch)

        states = torch.tensor(states, dtype=torch.float32)
        actions = torch.tensor(actions, dtype=torch.float32).unsqueeze(1)
        rewards = torch.tensor(rewards, dtype=torch.float32).unsqueeze(1)
        next_states = torch.tensor(next_states, dtype=torch.float32)

        _, next_values = self.target_model(next_states.unsqueeze(1))
        target_values = rewards + self.gamma * next_values.detach()

        _, values = self.model(states.unsqueeze(1))
        loss = nn.MSELoss()(values, target_values)

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        for target_param, param in zip(self.target_model.parameters(), self.model.parameters()):
            target_param.data.copy_(0.99 * target_param.data + 0.01 * param.data)

# === Training Loop ===
def train_agent(file_path, episodes=100):
    df = load_data(file_path)
    env = TradingEnv(df)
    agent = iRDPG(env)
    agg_rew = 0
    for episode in range(episodes):
        state = env.reset()
        total_reward = 0

        for _ in range(len(df) - 1):
            action = agent.select_action(state)
            next_state, reward, done, _ = env.step(action)
            agent.store_experience((state, action, reward, next_state), demo=(episode < 10))  # First 10 episodes are demonstrations
            state = next_state
            total_reward += reward

            if done:
                break
        agg_rew += total_reward
        agent.train()
        print(f"Episode {episode + 1}, Total Reward: {total_reward}")
        print(f"AGG REW = {agg_rew}")

# === Running the Training ===
train_agent("C:\\Users\\super\\Desktop\\Zelta\\untrade-sdk\\examples\\ETHUSDT_1h.csv")


# import numpy as np
# import pandas as pd
# import gym
# import random
# import torch
# import torch.nn as nn
# import torch.optim as optim
# from collections import deque

# # === Data Preprocessing ===
# def load_data(file_path):
#     df = pd.read_csv(file_path)
#     df['BuyLine'] = df['open'] + 0.5 * (df['high'] - df['low'])
#     df['SellLine'] = df['open'] - 0.5 * (df['high'] - df['low'])
#     return df

# # === Custom Gym Trading Environment ===
# class TradingEnv(gym.Env):
#     def __init__(self, df, initial_balance=500000, eta = 0.01):
#         super(TradingEnv, self).__init__()
#         self.df = df
#         self.index = 0
#         self.balance = initial_balance
#         self.position = 0  # 1: long, -1: short, 0: no position
#         self.total_profit = 0
#         self.done = False
#         self.observation_space = gym.spaces.Box(low=-np.inf, high=np.inf, shape=(6,))
#         self.action_space = gym.spaces.Discrete(2)  # Buy (1), Sell (-1)
#         self.slippage = 0.0002  # 0.02% price slippage
#         self.eta = eta  # Adaptation rate for Sharpe Ratio
#         self.alpha = 0  # Moving avg of returns
#         self.beta = 0   # Moving avg of squared returns
#         self.transaction_cost = 0.0001  # 0.01% transaction fee
#         self.slippage = 0.0002  # 0.02% price slippage

#     def reset(self):
#         self.index = 0
#         self.balance = 500000
#         self.position = 0
#         self.total_profit = 0
#         self.done = False
#         return self._next_observation()

#     def _next_observation(self):
#         row = self.df.iloc[self.index]
#         return np.array([row['open'], row['high'], row['low'], row['close'], row['BuyLine'], row['SellLine']])

#     # def step(self, action):
#     #     row = self.df.iloc[self.index]
#     #     reward = 0
#     #     if action == 1 and self.position == 0:
#     #         self.position = 1
#     #     elif action == -1 and self.position == 1:
#     #         reward = row['close'] - row['open']
#     #         self.position = 0
#     #         self.total_profit += reward
#     #     self.index += 1
#     #     if self.index >= len(self.df) - 1:
#     #         self.done = True
#     #     return self._next_observation(), reward, self.done, {}
#     def step(self, action):
#         """
#         Executes a trading step based on the agent's action.
#         """
#         row = self.df.iloc[self.index]
#         reward = 0
#         executed_price = row['close'] * (1 + self.slippage if action == 1 else 1 - self.slippage)

#         if action == 1 and self.position == 0:  # open Long
#             self.position = 1
#             self.entry_price = executed_price
#         elif action == -1 and self.position == 1:  # close Long
#             price_change = executed_price - self.entry_price
#             reward = self._calculate_reward(price_change)
#             self.position = 0
#             self.total_profit += price_change

#         self.index += 1
#         if self.index >= len(self.df) - 1:
#             self.done = True

#         return self._next_observation(), reward, self.done, {}

# # === Actor-Critic Model with GRU ===
# class ActorCritic(nn.Module):
#     def __init__(self, input_dim, hidden_dim):
#         super(ActorCritic, self).__init__()
#         self.gru = nn.GRU(input_dim, hidden_dim, batch_first=True)
#         self.actor = nn.Linear(hidden_dim, 1)
#         self.critic = nn.Linear(hidden_dim, 1)

#     def forward(self, x):
#         x, _ = self.gru(x)
#         x = x[:, -1, :]
#         action = torch.tanh(self.actor(x))  # Continuous action space
#         value = self.critic(x)
#         return action, value

# # === iRDPG Agent ===
# class iRDPG:
#     def __init__(self, env, hidden_dim=64, lr=0.001, gamma=0.99):
#         self.env = env
#         self.model = ActorCritic(input_dim=6, hidden_dim=hidden_dim).to("cpu")
#         self.target_model = ActorCritic(input_dim=6, hidden_dim=hidden_dim).to("cpu")
#         self.optimizer = optim.Adam(self.model.parameters(), lr=lr)
#         self.gamma = gamma
#         self.buffer = deque(maxlen=10000)
#         self.demo_buffer = deque(maxlen=5000)

#     def select_action(self, state):
#         state = torch.tensor(state, dtype=torch.float32).unsqueeze(0).unsqueeze(0)
#         action, _ = self.model(state)
#         return 1 if action.item() > 0 else -1

#     def store_experience(self, experience, demo=False):
#         if demo:
#             self.demo_buffer.append(experience)
#         else:
#             self.buffer.append(experience)

#     def train(self, batch_size=32):
#         if len(self.buffer) < batch_size:
#             return

#         minibatch = random.sample(self.buffer, batch_size // 2) + random.sample(self.demo_buffer, batch_size // 2)
#         states, actions, rewards, next_states = zip(*minibatch)

#         states = torch.tensor(states, dtype=torch.float32)
#         actions = torch.tensor(actions, dtype=torch.float32).unsqueeze(1)
#         rewards = torch.tensor(rewards, dtype=torch.float32).unsqueeze(1)
#         next_states = torch.tensor(next_states, dtype=torch.float32)

#         # Compute target values
#         _, next_values = self.target_model(next_states.unsqueeze(1))
#         target_values = rewards + self.gamma * next_values.detach()

#         # Compute current values
#         _, values = self.model(states.unsqueeze(1))
#         loss = nn.MSELoss()(values, target_values)

#         # Optimize the model
#         self.optimizer.zero_grad()
#         loss.backward()
#         self.optimizer.step()

#         # Soft update target network
#         for target_param, param in zip(self.target_model.parameters(), self.model.parameters()):
#             target_param.data.copy_(0.99 * target_param.data + 0.01 * param.data)

# # === Training Loop ===
# def train_agent(file_path, episodes=100):
#     df = load_data(file_path)
#     env = TradingEnv(df)
#     agent = iRDPG(env)

#     for episode in range(episodes):
#         state = env.reset()
#         total_reward = 0

#         for _ in range(len(df) - 1):
#             action = agent.select_action(state)
#             next_state, reward, done, _ = env.step(action)
#             agent.store_experience((state, action, reward, next_state), demo=(episode < 10))  # First 10 episodes are demonstrations
#             state = next_state
#             total_reward += reward

#             if done:
#                 break

#         agent.train()
#         print(f"Episode {episode + 1}, Total Reward: {total_reward}")

# # === Running the Training ===
# train_agent("C:\\Users\\super\\Desktop\\Zelta\\untrade-sdk\\examples\\ETHUSDT_1h.csv")
