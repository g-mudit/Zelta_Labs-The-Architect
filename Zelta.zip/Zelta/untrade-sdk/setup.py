from setuptools import setup, find_packages

setup(
    name="untrade",
    version="0.1.0",
    packages=find_packages(),
    author="Siddharth Jain",
    python_requires=">=3.8",
)
